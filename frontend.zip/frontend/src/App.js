import React from 'react';
import logo from './brand-logo.png';
import './App.css';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = { serverResponse: "" };
  }

  JSONtoTable(data) {
    var myjson = data
  
    var col = [];                                   // Extract table headers. 
    for (var i = 0; i < myjson.length; i++) {
      for (var key in myjson[i]) {
        if (col.indexOf(key) === -1) {
          col.push(key);
        }
      }
    }

    var table = document.createElement("table");    // create table.
    var tr = table.insertRow(-1);                   // create table row.

    for (var i = 0; i < col.length; i++) {
      var th = document.createElement("th");        // add table headers.
      th.innerHTML = col[i];
      tr.appendChild(th);
    }
  
    for (var i = 0; i < myjson.length; i++) {      // add json data as rows.
      tr = table.insertRow(-1);
      for (var j = 0; j < col.length; j++) {
        var tabCell = tr.insertCell(-1);
        tabCell.innerHTML = myjson[i][col[j]];
      }
    }
    
    var tablecontainer = document.getElementById("root");     // Add table to a container.
    tablecontainer.appendChild(table);
  }

  callAPIServer() {
    fetch("http://localhost:7000/mypage")
      .then(res => res.json())
      //.then(res => this.setState({ serverResponse: res }))
      .then(data => this.JSONtoTable(data))
      .catch(err => err);
  }

  componentDidMount() { 
    // react lifecycle method componentDidMount()
    //will execute the callAPIserver() method after the component mounts.
    this.callAPIServer();
  }

  render() {
    return (
      <div className="App" id="root">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1>Users Table</h1>
        </header>
        <body>
          <h2> Query Results on Frontend</h2>
        </body>
      </div>
    );
  }
}

export default App;